Both findings are **true positives and blocking for current CI acceptance**. Inspected HEAD `132215c17d187c527eeb7670f1dcbcb942f0ede1`; no edits, tests, delegation or external effects.

1. **Release original transfer: production regression — confidence 10/10.**  
   [ReleaseJobInputs.cs:46](/workspace/workflow-v3-boundary-contraction-20261013/src/private/app/workflow-delivery/Release/ReleaseJobInputs.cs:46) uses `Path.Combine(root, name)`, retaining slash-delimited relative components on Windows. The containment check at line 103 expects `sourceRoot + '\\'`. Thus an existing legitimate `preparation-scratch/build/original` fails the string-prefix check. Both Ruby and Python failures occur before byte-retention and escaping-input assertions.

   **Smallest correction:** use `Path.GetFullPath(Path.Combine(root, name))` inside `At`, before `RequireUnlinked` and returning the path. Keep the existing relative-path rejection, reparse-point checks, source-root containment and non-overwriting copy. Fix the production helper; changing fixture paths would hide the defect.

2. **Cancellation test readiness: existing test race — confidence 10/10.**  
   [NativeProcessTests.cs:140](/workspace/workflow-v3-boundary-contraction-20261013/tests/private/app/workflow-delivery/Platform/NativeProcessTests.cs:140) waits for existence, then reads once. Hosted Windows throws a sharing violation during that read. Staged `File.Move` does not guarantee that another handle permits reading immediately. This file is unchanged from the accepted base, so this is **not a newly introduced contraction regression**.

   **Smallest correction:** poll the actual PID read within the existing linked **15-second cancellation deadline**, retrying transient sharing/not-yet-present failures. Stop on cancellation or premature query completion; malformed PID content and permanent errors must remain failures. After obtaining the PID and process handle, retain explicit cancellation, awaiting `OperationCanceledException`, immediate `child.HasExited`, and existing cleanup.

   **Test-only readable-PID polling preserves truthful coverage: true.** It waits for an observed readiness condition while still exercising real PowerShell, real cancellation and real process exit. It neither simulates a platform guarantee nor justifies changing production termination logic. The observed failure happened before the termination assertion; the identity of the conflicting handle remains unresolved.

The actual first hosted run **remains failed**: run `38461566218`, job `115520218250`, tested merge candidate `92cdcd4e6700193bb0b347ef04a028aab27f80cb`, with **3 failed, 3,140 passed, 6 skipped**. These dispositions support necessary behavioral repairs and make no claim about cost improvement or #1160 ownership.

