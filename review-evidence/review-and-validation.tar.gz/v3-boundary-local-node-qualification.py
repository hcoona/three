import json, os, subprocess, sys
from pathlib import Path
root = Path('/workspace/workflow-v3-boundary-contraction-20261013')
sys.path.insert(0, str(root / 'eng/scripts'))
import run_node_ci_group as caller
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
state = Path('/tmp/v3-boundary-real-node-caller')
scope = Path('/tmp/v3-boundary-real-node-scope.json')
scope.write_text(json.dumps({'base': revision, 'candidate': revision, 'full': True,
    'changed_paths': [], 'endpoint_owners': {'basis': {'revision': revision, 'paths': []},
    'candidate': {'revision': revision, 'paths': []}}}))
group = caller.execute(root, scope, state)
outcome = caller.read_json(state / 'outcome.json')
assert outcome['satisfied'], outcome
assert len(group['runtime']['variants']) == 2
assert all(not (state / endpoint / 'node_modules').exists() for endpoint in ['basis','candidate'])
request = caller.read_json(state / 'planning-request.json')
request['full'] = False
joined = caller.read_json(state / 'scope-joined.json')
joined['full'] = False
empty_scope = state / 'empty-scope.json'
caller.write_json(empty_scope, joined)
request['scopePath'] = str(empty_scope)
for endpoint in ['basisControlFiles','candidateControlFiles']:
    for field in ['wrapper','request','response']:
        existing = Path(request[endpoint][field])
        request[endpoint][field] = str(existing.with_name('empty-' + existing.name))
empty_request = state / 'empty-request.json'
caller.write_json(empty_request, request)
application = state / 'control/WorkflowDelivery.dll'
raw = caller.run(state / 'candidate', state, 'empty-planning', 'mise','exec','--','dotnet',
    str(application),'ci','plan-node-group',str(empty_request))
empty = json.loads(raw)
assert empty['adopted']['checks'] == [] and empty['retained'] == [], empty
assert all(not (state / endpoint / 'node_modules').exists() for endpoint in ['basis','candidate'])
print(json.dumps({'revision': revision, 'fullChecks':len(group['adopted']['checks']),
    'runtimeVariants':group['runtime']['variants'], 'emptyChecks':0,
    'planningProductInstalls':0, 'satisfied':True}, indent=2))
