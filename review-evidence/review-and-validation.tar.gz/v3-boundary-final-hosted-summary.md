# Final Ordinary Hosted CI Observation

- Final source: `ae9553f443ef0e94da5eb3a855974771a6fd93eb`.
- Accepted comparison: `2911064651f3165d4eb6970838936ebce5459c4a`.
- Tested PR merge: `034e402c2d7011326d543e2ae427effdc2a24acd`, with those two parents.
- Both source and tested merge have tree `4be7bbfca6091685e01f6f8a5e1a3172e0fea5e9`.
- Ordinary CI [38468035622](https://github.com/hcoona/three/actions/runs/38468035622)
  completed successfully. Final PR checks: 23 successful, one skipped.
- Native collectors are satisfied with no errors or nonpassing required rows:
  .NET 92, Node 7, Python 22 and Ruby 4.
- The actual Windows controller test command exited zero with 3,150 passed,
  six skipped, total 3,156. Its default native MTP configuration remains
  unchanged; the separate required Windows NuGet native scenario job passed.
- Python's actual execution output records all 80 native Python tests passing,
  and all 22 required Python group checks passed. Both retained Node runtimes,
  the normal Ruby CI caller, Source conformance and CodeQL passed.

Original first-run failure and later Python failure remain retained. The later
run was cancelled by the superseding repair push; its incomplete .NET job is
not a passing observation. Local receipts keep their original source and host
scope. These are ordinary CI observations, not live registry/OIDC publication,
new product support, Windows native Ruby qualification or WD-NFR-005/P95
performance acceptance. The shared Wave remains for the independent cost work.
