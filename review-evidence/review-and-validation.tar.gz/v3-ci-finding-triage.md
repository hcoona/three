Content for `/tmp/v3-ci-finding-triage.md` follows. No file was written.

**All three findings are true positives.** Independent classifier: this Codex session, separate from the author, implementer and originating reviewer.

Reviewed HEAD `2911064651f3165d4eb6970838936ebce5459c4a`, current relevant source, predecessor files through `git show HEAD`, accepted governance/Wave/project contracts, and the preimplementation review. The working tree has expanded beyond the originating review’s captured snapshot; this classification does not approve the combined diff. Evidence is static; no edits, tests, builds or external operations occurred.

| Finding | Classification | Confidence |
|---|---|---|
| 1. Incomplete control-input coverage | True positive | 10/10 |
| 2. Changed resource-query context | True positive | 10/10 |
| 3. Current contracts prescribe retired mechanisms | True positive, with qualification below | 10/10 |

1. **Control-input coverage**

   **Evidence:** `Repository/DotNetGraph.cs:27–33,130–145` enumerates evaluated items and file properties without `Reference` HintPaths or several indirect compiler-file inputs. `Repository/DotNetRepositoryReader.cs:24–32` likewise lacks corresponding roles. `Repository/ControlInputs.cs:18–24` consumes owned paths and supplied graph rows; `DotNetOwnership.cs:35–43` limits ownership to project regions. Consequently, an otherwise unrepresented committed assembly outside the control region can affect compilation without becoming a control consumer.

   The predecessor `HEAD:Repository/ControlBuildInputProjection.cs:18–25,244–263` consumed compiler references and rejected nonempty unsupported indirect inputs. Native repository-target validation does not close this gap: ordinary evaluated items/properties need no custom repository target.

   **Smallest action:** Accept the proposed bounded native adaptation: extract evaluated `Reference` HintPaths, normalize them in their project context, and bind committed files through existing Git/provider validation. Inspect a finite set of indirect input properties and explicitly reject unsupported nonempty shapes. Retain concrete native-tool exceptions, including the target-produced official NBGV reference. Querying evaluated references alone does not establish coverage of target-produced references. No task replay is required.

2. **Resource-query context**

   **Evidence:** The predecessor `HEAD:Repository/ControlTestInputs.cs` calls `MsBuildResourceReader.ReadDefaultAsync(Project, "Debug", …)`. That reader’s `:58–63` supplies only Debug as an explicit global property. Current `ControlTestInputs.cs:36–46,74–81` takes resources from the root graph, whose reader `:65–71` additionally sets `ContinuousIntegrationBuild=true` and `RestoreLockedMode=true`.

   The accepted MLD `:382–391` expressly specifies the default Debug query. Conditional resources can differ between these contexts. Current `ControlTestInputsTests.cs:9–19,53–64` supplies constructed graph facts; it does not establish native evaluation equivalence. The preimplementation review already left unconditional query removal unresolved.

   **Smallest action:** Accept the proposed correction: preserve the existing Debug-only `MsBuildResourceReader` query and remove only redundant test-project restore where existing endpoint preparation satisfies its prerequisites. Retain paired endpoint resources, deletion/rename behavior, confirmed basis-owner absence and explicit evaluation failure.

   Produce the root graph later, once in its own CI context, and remove early production/reuse plumbing that becomes unnecessary. Do not force query merger or claim equivalence. Changing the accepted resource context would require owner disposition.

3. **Contract drift**

   **Evidence:** Current `docs/migration-strategy.md:669–720` still requires binary-log replay, task correlation and fresh compiler execution, while the proposed implementation deletes that machinery. `docs/middle-level-design.md:337` also retains a control-build binlog boundary. Migration `:749–759` fixes packaging to Node 24, whereas `Repository/NodeRuntimeInputs.cs:105–114` derives the packaging variant from configured Node and requires its presence in the workflow matrix.

   **Qualification:** The MLD’s separate default resource query is a valid retained contract under correction 2. It should remain; it is not independently obsolete.

   **Smallest action:** Atomically reconcile affected current design, integration and caller interfaces with the reviewed source/configuration graph contract and configuration-derived runtime selection. Preserve the same supported source checks, complete configured variant coverage, exact bindings, concrete tool exceptions and explicit unsupported cases. Preserve historical evidence unchanged. Documentation must not merely ratify omissions identified in finding 1.

These classifications satisfy the finding-classification step of GOV-011. Repairs remain unverified and must return to independent review. Persist this result in the governing PR/review carrier; it supplies neither merge acceptance nor performance or publication qualification.

