### Rule Group 1: system / .github/workflows/**/*.{yaml,yml}

Applies to:
- .github/workflows/ci.yml
- .github/workflows/workflow-delivery-v3-buddy-smoke.yml
- .github/workflows/workflow-delivery-v3-python-smoke.yml
- .github/workflows/workflow-delivery-v3-ruby-smoke.yml

#### Content

#### Security
- **pull_request_target misuse**: Using `pull_request_target` with `actions/checkout` referencing PR head code is dangerous — it runs untrusted code with write permissions. Flag if checkout ref points to PR head without isolation
- **Secrets exposure**: Secrets must not be printed to logs (e.g., `echo ${{ secrets.X }}`). Verify secrets are only passed via `env:` blocks to steps that need them
- **Excessive permissions**: Check if `permissions` is set to least-privilege. Flag `permissions: write-all` or missing `permissions` key (defaults to broad access). Each job should declare only the permissions it needs
- **Unpinned action versions**: Third-party actions should be pinned to a full commit SHA (e.g., `uses: actions/checkout@<sha>`), not just a tag. Tags are mutable and can be hijacked. First-party (`actions/*`) pinned to `v4` is acceptable
- **Script injection**: Expressions like `${{ github.event.issue.title }}` used directly in `run:` blocks enable code injection. These must be passed through environment variables instead
- **Hardcoded credentials**: Tokens, passwords, or API keys directly in the workflow file (not via secrets)

#### Correctness
- **Missing `fetch-depth: 0`**: When a workflow needs git history (tags, merge-base, changelog generation), verify `actions/checkout` uses `fetch-depth: 0`
- **Incorrect condition logic**: Verify `if:` conditions are correct (e.g., `github.event_name == 'pull_request'` vs `'pull_request_target'`); ensure boolean expressions are properly quoted
- **Matrix strategy gaps**: Check that matrix combinations cover required platforms. Flag if `fail-fast` is true (default) but all matrix legs must succeed
- **Missing `shell` specification**: When using `run:` with multi-line scripts on self-hosted runners, shell should be explicit (bash vs sh vs pwsh)
- **Broken job dependencies**: Verify `needs:` references exist as actual job IDs in the same workflow. Check for circular dependencies
- **Typos in action inputs**: Misspelled input names for actions (e.g., `fetch-detph` instead of `fetch-depth`) are silently ignored

#### Reliability
- **Missing timeout**: Jobs without `timeout-minutes` can run indefinitely and consume runner resources. Flag jobs that lack timeout (especially on self-hosted runners)
- **No concurrency control**: Workflows triggered by push/PR without `concurrency` group may create redundant runs. Suggest `concurrency` with `cancel-in-progress` where appropriate
- **Uncached dependencies**: Build workflows that install dependencies without caching (no `actions/cache` or built-in caching) on every run

#### Best Practices
- **Deprecated features**: Flag usage of deprecated syntax (`set-output`, `save-state`, `::set-output`, `actions/checkout@v2/v3` when v4 is available)
- **Missing `continue-on-error` awareness**: If a step failure should not fail the whole job, it needs `continue-on-error: true`; conversely, verify non-critical steps don't silently swallow failures with `|| true` hiding real errors
- **Container image tags**: Using `latest` tag for container images is unreliable; prefer specific version tags

---

### Rule Group 2: system / **/*.{py,pyi,ipynb}

Applies to:
- eng/scripts/prepare_ci_control_inputs.py
- eng/scripts/run_dotnet_ci_group.py
- eng/scripts/run_node_ci_group.py
- src/private/app/workflow-delivery/Native/Python/packages.py

#### Content

> Favor precision over recall: only raise an issue when you are confident it is a real defect, and stay silent when the surrounding context is unclear — a false alarm costs more reviewer trust than a missed minor issue. Treat security and correctness findings as blocking, and style or idiom suggestions as non-blocking.

#### Obvious Typos or Spelling Errors
- Spelling errors in variable, function, class, or module names at their declaration sites; do not report spelling errors at reference sites, as these are determined by the declaration
- Strings in log messages or exception messages containing spelling errors that affect readability

#### Dead Code
- Code blocks that can never be reached (e.g., branches where the condition is always false, code after a `return`, `raise`, `break`, or `continue`)
- Variables, imports, or function parameters that are declared but never read or referenced
- Large blocks of commented-out code with no apparent intent to preserve
- Do not report unused imports, variables, or parameters in `.pyi` stub files; a stub declares an interface it never executes, so re-exported imports, annotation-only declarations, and unreferenced parameter names are expected rather than dead

#### Mutable Default Arguments and Shared State
- Mutable default arguments such as `def f(x=[])` or `def f(x={})`; the default is created once and shared across every call. Default to `None` and build the value inside the body
- Class-level mutable attributes shared unintentionally across instances when a per-instance value was intended
- Module-level mutable globals (lists, dicts, caches) mutated across requests or threads, retaining state in ways that surprise the caller
- Closures that capture a loop variable by reference and all end up seeing its final value
- Do not report when the function never mutates the argument, or when the shared default is a deliberate, documented cache or sentinel

#### Boundary and Edge-Case Handling
- Empty inputs assumed to be non-empty: indexing `xs[0]`, `max()`/`min()`, or slicing without first handling the empty `list`, `str`, `dict`, or iterator
- Off-by-one and out-of-range access on indices, ranges, or slices, especially at the first/last element
- `None` reaching code that assumes a value, when an upstream call or default can legitimately return `None` (confirm the data source with `file_read` before flagging)
- Comparing floats for exact equality with `==`; use `math.isclose` or an explicit tolerance, since floating-point results are not exact
- Integer/float and division assumptions: unintended truncation with `//`, or `ZeroDivisionError` when a divisor can be zero
- Heterogeneous or unexpected element types in a collection that the code assumes are uniform (e.g., mixing `None`, numbers, and strings)
- Dictionary access by key without handling the missing-key case (`d[k]` vs `d.get(k)`), or set/dict operations that assume a key is present
- Do not report edge cases that a caller or type contract has already ruled out, or inputs that cannot occur given validated boundaries upstream

#### Error Handling and Exceptions
- Bare `except:` swallows everything, including `KeyboardInterrupt` and `SystemExit`; catch `except Exception` at minimum, and prefer the specific exception types you expect
- `except Exception` that is still broader than the failure being handled; narrow it to the exceptions actually raised by the guarded call
- Exceptions caught and silently discarded (`pass`) without logging or re-raising
- Original traceback lost when re-raising; prefer `raise NewError(...) from err` to preserve the cause
- Broad `try` blocks that wrap far more than the line that can actually fail, hiding where the error originates
- `assert` used for runtime validation of external input — assertions are stripped under `python -O`

#### Identity and Equality Comparisons
- Using `is`/`is not` to compare against literals such as strings, numbers, or tuples; this relies on implementation-specific interning rather than value equality — use `==` (a real correctness risk)
- Comparing against `True`/`False` with `==`, where a truthy-but-not-`True` value (e.g. `1`, a non-empty container) would compare unequal; prefer a plain truthiness check
- Reserve `is` for identity checks against singletons and sentinels
- Comparing against `None` with `==`/`!=` rather than `is`/`is not` is a style preference; report as minor, not blocking

#### Resource Management
- Files, sockets, locks, or database connections opened without a `with` statement, risking leaks on early return or exception
- Context managers available but bypassed in favor of manual `open()`/`close()` pairs
- Resources acquired in a `try` whose `finally` cleanup is missing or incomplete on the error path
- Iterators or generators holding resources open longer than necessary
- Do not report short-lived scripts, or handles already managed by an enclosing `with` or framework-managed lifecycle (confirm the surrounding scope with `file_read` before flagging)

#### Performance
Confirm data scale and that the code is on a hot path before flagging:
- Building strings with `+=` in a loop instead of accumulating in a list and `"".join(...)`, or using an f-string
- Repeated membership tests against a `list` where a `set` or `dict` would turn O(n) lookups into O(1)
- Building a full list when a generator would avoid holding everything in memory
- Recomputing inside a loop a value that is invariant across iterations (e.g., compiling a regex, attribute lookups in hot paths)
- Passing an eagerly formatted f-string to `logging` (e.g., `logging.info(f"...")`) instead of `logging.info("%s", value)`, which defeats lazy formatting when the level is disabled

#### Concurrency and Async
Only flag concurrency issues when there is evidence of multi-threaded, multi-process, or async invocation (confirm the call context before reporting):
- CPU-bound work parallelized with `threading` under the GIL where `multiprocessing` or a process pool is the right tool (traditional CPython; free-threaded builds excepted); I/O-bound work is the case threads actually help
- Check-then-act races on shared state without a `Lock`, or non-atomic compound updates assumed to be atomic
- Blocking calls (synchronous I/O, `time.sleep`, `requests`, CPU-heavy work) inside `async def`, stalling the event loop; use the async equivalent or run them in an executor
- `asyncio` tasks created and never awaited, so exceptions are swallowed and the work may be garbage-collected before it finishes
- Shared mutable state across threads or tasks without synchronization or a thread-safe structure

Do not report local variables (each thread has its own), read-only access to shared data, or code with no evidence of concurrent use.

#### Security-Sensitive Code
Validate the data source before flagging; confirm the input is actually attacker-controlled rather than a trusted constant:
- `eval`, `exec`, or `compile` on untrusted input; this is arbitrary code execution
- `subprocess` with `shell=True` built from unsanitized input; pass an argument list and avoid the shell
- `pickle`, `marshal`, or `yaml.load` (without `SafeLoader`) on untrusted data; deserialization can execute arbitrary code
- SQL built by string concatenation or f-strings instead of parameterized queries
- Secrets, tokens, passwords, or PII written to logs or committed in source
- Weak or misused cryptography (`hashlib.md5`/`sha1` for passwords, `random` for security tokens); use `secrets` and vetted libraries
- Untrusted file paths joined without validation, allowing path traversal

---

### Rule Group 3: system / default

Applies to:
- pyproject.toml
- src/private/app/workflow-delivery/CI/NodeExecution.cs
- src/private/app/workflow-delivery/CI/PythonPackageExecution.cs
- src/private/app/workflow-delivery/CI/RubyPackageExecution.cs
- src/private/app/workflow-delivery/Destinations/GithubNpmConsumer.cs
- src/private/app/workflow-delivery/Destinations/GithubNpmPublication.cs
- src/private/app/workflow-delivery/Destinations/PythonNativePublisher.cs
- src/private/app/workflow-delivery/Ecosystems/AdoptedNpmPackage.cs
- src/private/app/workflow-delivery/Ecosystems/DotNetSmokeRemoteConsumer.cs
- src/private/app/workflow-delivery/Ecosystems/NpmPackageOperations.cs
- src/private/app/workflow-delivery/Ecosystems/PythonRemoteConsumer.cs
- src/private/app/workflow-delivery/Ecosystems/PythonSmokePackageOperations.cs
- src/private/app/workflow-delivery/Ecosystems/RubyNativePublisher.cs
- src/private/app/workflow-delivery/Ecosystems/RubyRemoteConsumer.cs
- src/private/app/workflow-delivery/Ecosystems/RubySmokePackageOperations.cs
- src/private/app/workflow-delivery/Ecosystems/RubySourceReader.cs
- src/private/app/workflow-delivery/Native/Ruby/consumer.rb
- src/private/app/workflow-delivery/Program.cs
- src/private/app/workflow-delivery/Release/NpmPreparation.cs
- src/private/app/workflow-delivery/Release/NuGetRelease.cs
- src/private/app/workflow-delivery/Release/PythonPreparation.cs
- src/private/app/workflow-delivery/Release/PythonRelease.cs
- src/private/app/workflow-delivery/Release/ReleaseCli.cs
- src/private/app/workflow-delivery/Release/ReleaseJobInputs.cs
- src/private/app/workflow-delivery/Release/RubyPreparation.cs
- src/private/app/workflow-delivery/Release/RubyRelease.cs
- src/private/app/workflow-delivery/Repository/ControlInputs.cs
- src/private/app/workflow-delivery/Repository/DotNetGraph.cs
- src/private/app/workflow-delivery/Repository/DotNetGroupReader.cs
- src/private/app/workflow-delivery/Repository/DotNetRepositoryReader.cs
- src/private/app/workflow-delivery/Repository/NativeMessageSchemas.cs
- src/private/app/workflow-delivery/Repository/NodeGroupReader.cs
- src/private/app/workflow-delivery/Repository/NodeRuntimeInputs.cs
- src/private/app/workflow-delivery/Repository/PythonPackageChecks.cs
- src/private/app/workflow-delivery/Repository/PythonRepositoryInputs.cs
- src/private/app/workflow-delivery/Repository/RubyFactMessages.cs
- src/private/app/workflow-delivery/Repository/RubyNativeFactsReader.cs
- tests/private/app/workflow-delivery/CI/NodeExecutionFixture.cs
- tests/private/app/workflow-delivery/CI/NodeExecutionTests.cs
- tests/private/app/workflow-delivery/Release/DotNetRemoteConsumerTests.cs
- tests/private/app/workflow-delivery/Release/GithubNpmConsumerTests.cs
- tests/private/app/workflow-delivery/Release/GithubNpmPublicationTests.cs
- tests/private/app/workflow-delivery/Release/NuGetConsumerReadHandlerTests.cs
- tests/private/app/workflow-delivery/Release/NuGetPreparationNativeTests.cs
- tests/private/app/workflow-delivery/Release/PythonPreparationNativeTests.cs
- tests/private/app/workflow-delivery/Release/ReleaseJobInputsTests.cs
- tests/private/app/workflow-delivery/Release/RubyPreparationNativeTests.cs
- tests/private/app/workflow-delivery/Repository/ControlInputsTests.cs
- tests/private/app/workflow-delivery/Repository/DotNetGraphTaskTests.cs
- tests/private/app/workflow-delivery/Repository/DotNetGroupReaderTests.cs
- tests/private/app/workflow-delivery/Repository/NativeMessageSchemasTests.cs
- tests/private/app/workflow-delivery/Repository/NodeGroupReaderTests.cs
- tests/private/app/workflow-delivery/Repository/NodeRuntimeInputsTests.cs
- tests/private/app/workflow-delivery/Repository/PythonRepositoryInputsTests.cs
- tests/private/app/workflow-delivery/Repository/RubyNodeInputConsumersTests.cs

#### Content

#### Correctness
Is the logic correct? Are there missing boundary conditions?
Are exceptions handled properly?
Is it thread-safe in concurrent scenarios?

#### Security
Are there security vulnerabilities such as SQL injection or XSS?
Is sensitive information handled correctly?
Is permission validation complete?

#### Performance
Are there obvious performance issues (e.g., N+1 queries, unnecessary loops)?
Are resources properly released?

#### Maintainability
Is the code clear and easy to understand?
Do names accurately express intent?
Does it follow the project’s existing code style and architecture patterns?

#### Test Coverage
Do critical logic paths have corresponding test cases?
Do test cases cover boundary conditions?

---

### Rule Group 4: system / **/*.{json,json5}

Applies to:
- src/private/app/workflow-delivery/Native/contracts/ruby-archive.schema.json
- src/private/app/workflow-delivery/Native/contracts/ruby-bundle.schema.json
- src/private/app/workflow-delivery/Native/contracts/ruby-consumer-answer.schema.json
- src/private/app/workflow-delivery/Native/contracts/ruby-consumer-request.schema.json
- src/private/app/workflow-delivery/Native/contracts/ruby-context.schema.json
- src/private/app/workflow-delivery/Native/contracts/ruby-fact-request.schema.json
- src/private/app/workflow-delivery/Native/contracts/ruby-source-answer.schema.json
- src/private/app/workflow-delivery/Native/contracts/ruby-source-request.schema.json
- src/private/app/workflow-delivery/Native/contracts/ruby-source.schema.json
- src/private/app/workflow-delivery/Native/contracts/ruby-version.schema.json

#### Content

Check JSON files for spelling errors in json-keys; ignore the content of json-values.
