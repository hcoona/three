# Files (2 reviewable / 2 total)

- mode: workspace
- total_insertions: 15
- total_deletions: 5

  - `src/private/app/workflow-delivery/Release/ReleaseJobInputs.cs` [modified] +1/-1
  - `tests/private/app/workflow-delivery/Platform/NativeProcessTests.cs` [modified] +14/-4
