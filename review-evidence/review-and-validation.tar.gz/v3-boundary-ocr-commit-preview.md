# Files (73 reviewable / 100 total)

- mode: range
- from: origin/main
- to: HEAD
- merge_base: 2911064651f3165d4eb6970838936ebce5459c4a
- total_insertions: 1978
- total_deletions: 5352

  - `.github/workflows/ci.yml` [modified] +2/-5
  - `.github/workflows/workflow-delivery-v3-buddy-smoke.yml` [modified] +14/-6
  - `.github/workflows/workflow-delivery-v3-python-smoke.yml` [modified] +39/-27
  - `.github/workflows/workflow-delivery-v3-ruby-smoke.yml` [modified] +20/-20
  - `eng/scripts/prepare_ci_control_inputs.py` [modified] +4/-21
  - `eng/scripts/run_dotnet_ci_group.py` [modified] +4/-31
  - `eng/scripts/run_node_ci_group.py` [modified] +30/-22
  - `pyproject.toml` [modified] +1/-1
  - `src/private/app/workflow-delivery/CI/NodeExecution.cs` [modified] +33/-22
  - `src/private/app/workflow-delivery/CI/PythonPackageExecution.cs` [modified] +2/-2
  - `src/private/app/workflow-delivery/CI/RubyPackageExecution.cs` [modified] +1/-1
  - `src/private/app/workflow-delivery/Destinations/GithubNpmConsumer.cs` [modified] +4/-6
  - `src/private/app/workflow-delivery/Destinations/GithubNpmPublication.cs` [modified] +18/-2
  - `src/private/app/workflow-delivery/Destinations/PythonNativePublisher.cs` [modified] +2/-1
  - `src/private/app/workflow-delivery/Ecosystems/AdoptedNpmPackage.cs` [modified] +7/-0
  - `src/private/app/workflow-delivery/Ecosystems/DotNetSmokeRemoteConsumer.cs` [renamed] +4/-3
  - `src/private/app/workflow-delivery/Ecosystems/NpmPackageOperations.cs` [modified] +0/-5
  - `src/private/app/workflow-delivery/Ecosystems/PythonRemoteConsumer.cs` [modified] +4/-4
  - `src/private/app/workflow-delivery/Ecosystems/PythonSmokePackageOperations.cs` [renamed] +3/-2
  - `src/private/app/workflow-delivery/Ecosystems/RubyNativePublisher.cs` [modified] +2/-2
  - `src/private/app/workflow-delivery/Ecosystems/RubyRemoteConsumer.cs` [modified] +13/-12
  - `src/private/app/workflow-delivery/Ecosystems/RubySmokePackageOperations.cs` [renamed] +2/-3
  - `src/private/app/workflow-delivery/Ecosystems/RubySourceReader.cs` [modified] +14/-13
  - `src/private/app/workflow-delivery/Native/Python/packages.py` [modified] +2/-2
~~- `src/private/app/workflow-delivery/Native/Python/release_caller.py` [deleted] +0/-219 (excluded: deleted)~~
  - `src/private/app/workflow-delivery/Native/Ruby/consumer.rb` [modified] +2/-0
~~- `src/private/app/workflow-delivery/Native/Ruby/release_caller.rb` [deleted] +0/-130 (excluded: deleted)~~
  - `src/private/app/workflow-delivery/Native/contracts/ruby-archive.schema.json` [added] +65/-0
  - `src/private/app/workflow-delivery/Native/contracts/ruby-bundle.schema.json` [added] +128/-0
  - `src/private/app/workflow-delivery/Native/contracts/ruby-consumer-answer.schema.json` [added] +16/-0
  - `src/private/app/workflow-delivery/Native/contracts/ruby-consumer-request.schema.json` [added] +22/-0
  - `src/private/app/workflow-delivery/Native/contracts/ruby-context.schema.json` [added] +19/-0
  - `src/private/app/workflow-delivery/Native/contracts/ruby-fact-request.schema.json` [added] +16/-0
  - `src/private/app/workflow-delivery/Native/contracts/ruby-source-answer.schema.json` [added] +34/-0
  - `src/private/app/workflow-delivery/Native/contracts/ruby-source-request.schema.json` [added] +19/-0
  - `src/private/app/workflow-delivery/Native/contracts/ruby-source.schema.json` [added] +59/-0
  - `src/private/app/workflow-delivery/Native/contracts/ruby-version.schema.json` [added] +19/-0
  - `src/private/app/workflow-delivery/Program.cs` [modified] +7/-0
~~- `src/private/app/workflow-delivery/README.md` [modified] +10/-1 (excluded: unsupported_ext)~~
  - `src/private/app/workflow-delivery/Release/NpmPreparation.cs` [modified] +1/-1
  - `src/private/app/workflow-delivery/Release/NuGetRelease.cs` [modified] +2/-1
  - `src/private/app/workflow-delivery/Release/PythonPreparation.cs` [modified] +4/-4
  - `src/private/app/workflow-delivery/Release/PythonRelease.cs` [modified] +2/-1
  - `src/private/app/workflow-delivery/Release/ReleaseCli.cs` [modified] +1/-0
  - `src/private/app/workflow-delivery/Release/ReleaseJobInputs.cs` [added] +199/-0
  - `src/private/app/workflow-delivery/Release/RubyPreparation.cs` [modified] +2/-2
  - `src/private/app/workflow-delivery/Release/RubyRelease.cs` [modified] +1/-1
~~- `src/private/app/workflow-delivery/Repository/ControlBuildContextReader.cs` [deleted] +0/-176 (excluded: deleted)~~
~~- `src/private/app/workflow-delivery/Repository/ControlBuildDependencyReader.cs` [deleted] +0/-204 (excluded: deleted)~~
~~- `src/private/app/workflow-delivery/Repository/ControlBuildInputProjection.cs` [deleted] +0/-504 (excluded: deleted)~~
~~- `src/private/app/workflow-delivery/Repository/ControlBuildLogReader.cs` [deleted] +0/-281 (excluded: deleted)~~
  - `src/private/app/workflow-delivery/Repository/ControlInputs.cs` [added] +50/-0
  - `src/private/app/workflow-delivery/Repository/DotNetGraph.cs` [modified] +24/-1
  - `src/private/app/workflow-delivery/Repository/DotNetGroupReader.cs` [modified] +11/-27
  - `src/private/app/workflow-delivery/Repository/DotNetRepositoryReader.cs` [modified] +14/-7
  - `src/private/app/workflow-delivery/Repository/NativeMessageSchemas.cs` [added] +36/-0
  - `src/private/app/workflow-delivery/Repository/NodeGroupReader.cs` [modified] +19/-26
  - `src/private/app/workflow-delivery/Repository/NodeRuntimeInputs.cs` [modified] +24/-20
  - `src/private/app/workflow-delivery/Repository/PythonPackageChecks.cs` [modified] +1/-1
  - `src/private/app/workflow-delivery/Repository/PythonRepositoryInputs.cs` [modified] +8/-7
  - `src/private/app/workflow-delivery/Repository/RubyFactMessages.cs` [added] +58/-0
  - `src/private/app/workflow-delivery/Repository/RubyNativeFactsReader.cs` [modified] +71/-85
~~- `src/private/app/workflow-delivery/WorkflowDelivery.csproj` [modified] +1/-0 (excluded: unsupported_ext)~~
~~- `src/private/app/workflow-delivery/docs/agent-handoff.md` [modified] +9/-1 (excluded: unsupported_ext)~~
~~- `src/private/app/workflow-delivery/docs/high-level-design.md` [modified] +8/-2 (excluded: unsupported_ext)~~
~~- `src/private/app/workflow-delivery/docs/middle-level-design.md` [modified] +7/-6 (excluded: unsupported_ext)~~
~~- `src/private/app/workflow-delivery/docs/migration-strategy.md` [modified] +106/-98 (excluded: unsupported_ext)~~
~~- `tests/eng/test_ci_scope.py` [modified] +1/-9 (excluded: default_path)~~
~~- `tests/eng/test_python_release_caller.py` [modified] +102/-381 (excluded: default_path)~~
~~- `tests/eng/test_ruby_release_caller.py` [deleted] +0/-645 (excluded: default_path)~~
~~- `tests/eng/test_run_dotnet_ci_group.py` [modified] +3/-5 (excluded: default_path)~~
~~- `tests/eng/test_run_node_ci_group.py` [modified] +8/-12 (excluded: default_path)~~
~~- `tests/eng/test_run_python_ci_group.py` [modified] +1/-1 (excluded: default_path)~~
  - `tests/private/app/workflow-delivery/CI/NodeExecutionFixture.cs` [modified] +1/-1
  - `tests/private/app/workflow-delivery/CI/NodeExecutionTests.cs` [modified] +6/-5
~~- `tests/private/app/workflow-delivery/Native/Ruby/test_consumer.py` [modified] +12/-1 (excluded: default_path)~~
~~- `tests/private/app/workflow-delivery/Native/Ruby/test_facts.py` [modified] +25/-5 (excluded: default_path)~~
~~- `tests/private/app/workflow-delivery/Native/Ruby/test_source.py` [modified] +11/-1 (excluded: default_path)~~
  - `tests/private/app/workflow-delivery/Release/DotNetRemoteConsumerTests.cs` [modified] +12/-10
  - `tests/private/app/workflow-delivery/Release/GithubNpmConsumerTests.cs` [modified] +2/-0
  - `tests/private/app/workflow-delivery/Release/GithubNpmPublicationTests.cs` [modified] +2/-0
  - `tests/private/app/workflow-delivery/Release/NuGetConsumerReadHandlerTests.cs` [modified] +1/-1
  - `tests/private/app/workflow-delivery/Release/NuGetPreparationNativeTests.cs` [modified] +3/-3
  - `tests/private/app/workflow-delivery/Release/PythonPreparationNativeTests.cs` [modified] +11/-20
  - `tests/private/app/workflow-delivery/Release/ReleaseJobInputsTests.cs` [added] +225/-0
  - `tests/private/app/workflow-delivery/Release/RubyPreparationNativeTests.cs` [modified] +11/-27
~~- `tests/private/app/workflow-delivery/Repository/ControlBuildContextReaderTests.cs` [deleted] +0/-209 (excluded: deleted)~~
~~- `tests/private/app/workflow-delivery/Repository/ControlBuildInputProjectionTests.cs` [deleted] +0/-967 (excluded: deleted)~~
~~- `tests/private/app/workflow-delivery/Repository/ControlBuildLogReaderTests.cs` [deleted] +0/-401 (excluded: deleted)~~
  - `tests/private/app/workflow-delivery/Repository/ControlInputsTests.cs` [added] +56/-0
~~- `tests/private/app/workflow-delivery/Repository/ControlWorkloadInputsTests.cs` [deleted] +0/-426 (excluded: deleted)~~
  - `tests/private/app/workflow-delivery/Repository/DotNetGraphTaskTests.cs` [modified] +83/-0
  - `tests/private/app/workflow-delivery/Repository/DotNetGroupReaderTests.cs` [modified] +3/-7
  - `tests/private/app/workflow-delivery/Repository/NativeMessageSchemasTests.cs` [added] +56/-0
  - `tests/private/app/workflow-delivery/Repository/NodeGroupReaderTests.cs` [modified] +3/-5
  - `tests/private/app/workflow-delivery/Repository/NodeRuntimeInputsTests.cs` [modified] +22/-3
  - `tests/private/app/workflow-delivery/Repository/PythonRepositoryInputsTests.cs` [modified] +13/-185
  - `tests/private/app/workflow-delivery/Repository/RubyNodeInputConsumersTests.cs` [modified] +3/-1
~~- `tests/private/app/workflow-delivery/fixtures/products/hcoona-release-smoke-ruby/hcoona-release-smoke-ruby.gemspec` [modified] +0/-2 (excluded: default_path)~~
~~- `uv.lock` [modified] +2/-0 (excluded: unsupported_ext)~~
