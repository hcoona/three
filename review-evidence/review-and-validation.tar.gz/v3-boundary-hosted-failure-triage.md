**True positive: blocking planning regression, confidence 10/10.** The narrow documentation exclusion is valid; its representation in Python facts is incomplete.

The supplied log records `ci plan-python-group` failing with `Unresolved Python input: src/private/app/workflow-delivery/README.md`, CLI exit 2, in run **38461566218**, job **115520218415**. It identifies the tested PR merge as `92cdcd4e6700193bb0b347ef04a028aab27f80cb`, incorporating candidate `3b1503c5f9c3c059a815ecdbb925ac82eea6dfee`. The current worktree is clean at that candidate.

The source explains the failure:

- [PythonRepositoryInputs.cs:226](/workspace/workflow-v3-boundary-contraction-20261013/src/private/app/workflow-delivery/Repository/PythonRepositoryInputs.cs:226) excludes the control README and `docs/**` from broad preparation-consumer mappings. It emits no replacement binding identifying these paths as known nonconsumers.
- [ci_scope.py:642](/workspace/workflow-v3-boundary-contraction-20261013/eng/scripts/ci_scope.py:642) still assigns Python caller responsibility to every path beneath the control application.
- [PythonGroupReader.cs:81](/workspace/workflow-v3-boundary-contraction-20261013/src/private/app/workflow-delivery/Repository/PythonGroupReader.cs:81) supplies zero-consumer bindings from other responsibilities only when **all** scope reasons are non-Python. That broad Python reason prevents this route.
- [PythonOwnerProjection.cs:90](/workspace/workflow-v3-boundary-contraction-20261013/src/private/app/workflow-delivery/Repository/PythonOwnerProjection.cs:90) correctly rejects a path with no native member, input binding or quality owner. The README therefore reaches the unresolved-input guard.

**Control `docs/**` shares the defect.** It has the same exclusion and scope responsibility, so an otherwise unconsumed changed document follows the same failure path. This is a source-backed inference; the hosted log directly demonstrates the README failure.

**Smallest correction:** in `PythonRepositoryInputs.Map`, emit an explicit `PythonInputBinding(path, [], [])` for the exact excluded control README and inert control-documentation coordinates at each applicable endpoint.

The existing machinery already supports this distinction:

- `PythonOwnerProjection` accepts an explicit empty binding while retaining its unresolved-input guard.
- [PythonFactsAssembler.cs:27](/workspace/workflow-v3-boundary-contraction-20261013/src/private/app/workflow-delivery/Repository/PythonFactsAssembler.cs:27) marks a path unaffected only when every endpoint impact has zero owners.
- Actual native, quality and paired consumer bindings remain additive and must take precedence over nonconsumer status.

Preserve the complete changed-path set and paired deletion/rename handling. Limit empty bindings to the established exclusions; arbitrary unmapped paths must still fail. Keep real resources, helper sources, schemas, configuration and preparation consumers intact.

This repairs the missing distinction between **known nonconsumer** and **unresolved input**, preserving WD-CI-002/003/010. It requires neither broad control-directory consumers nor a full-run fallback, and does not require changing the generic projection guard.

This is the independent GOV-011 disposition before repair. No edits, tests, delegation or external operations occurred; the proposed correction remains unqualified.

