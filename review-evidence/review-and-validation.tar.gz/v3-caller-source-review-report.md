# Independent bounded engineering/OCR source review

Reviewer: independent source-review session requested by the owner; no authorship or implementation work performed in this session.

Subject: `/workspace/workflow-v3-caller-followup-20261013` working-tree changes against accepted base/HEAD `7be1babcb429c97bc68e3aa7a00f4faa4cccb3bf`, inspected on 2026-10-14 UTC. This is a source review with supplied qualification-log observations, not a merge, publication, hosted-runner, or performance acceptance.

## Outcome

No material findings remain in the exact twenty-one-file reviewed source. F1 is closed for this bounded engineering/OCR review: independently classified true positive, source correction inspected, and complete post-repair local qualification observed. Its original finding and failed run remain below as historical evidence. This closure relies on the separate classification in `/tmp/v3-caller-F1-triage.md`; it is not self-classification.

The final recheck below supersedes earlier pending qualification statuses. It does not establish global architecture closure, performance acceptance, hosted/Windows qualification, live readiness or merge authorization. Root retains verification of HK PTY 85101's terminal process status.

## F1: Closed; original finding and source correction

**Final status:** true positive per independent triage, confidence 10/10; source repaired and inspected; post-repair complete managed suite passed locally. The following JSON and original evidence describe the earlier source, not a remaining defect.

```json
{
  "path": "src/private/app/workflow-delivery/Program.cs",
  "start_line": 166,
  "end_line": 167,
  "category": "test",
  "severity": "medium",
  "content": "The CLI now correctly forwards the aggregate owner's bound outcome, but DotNetGroupExecutionTests.CliCollectsOriginalTransferredPlanDespiteClaimedOutcome still supplies Satisfied=true for incomplete raw results and expects the CLI to recollect them and return 1. Its false row now returns 0; the supplied managed-full log records precisely this failure. Reconcile this retained test with the new boundary while preserving complete-plan missing-result evaluation at the aggregate owner. Do not restore duplicate CLI collection to satisfy the obsolete mock expectation."
}
```

- **Rule:** accepted Wave requires atomic reconciliation of affected callers and complete retained validation; shared engineering Testing guidance protects behavior rather than incidental orchestration. WD-CI-006/007 still require missing results to prevent success at their actual owner. The proposed integration contract assigns complete-plan evaluation to group execution.
- **Confidence:** 10/10.
- **Concrete evidence:** `tests/private/app/workflow-delivery/CI/DotNetGroupExecutionTests.cs:213-245`, particularly the unconditional successful mock outcome at line 236 and expected exit at line 238. `Program.cs:166-167` uses `GroupExit`; `CI/DotNetGroupExecution.cs:79-83` evaluates the original complete plan before returning its aggregate. `/tmp/v3-caller-managed-full.log` records the `(False,1)` row failing with expected 1, actual 0 at line 238.
- **Smallest required action:** replace the obsolete CLI recollection scenario with a faithful bound aggregate outcome, assert its forwarding and exit, and retain aggregate-level incomplete-result coverage already present in `DotNetGroupExecutionTests.cs:102-106`. Requalify the affected complete suite after reconciliation. Extend subject/failure coverage only where needed; no second production collector is justified.
- **Limit:** this is a test-contract migration defect and observed qualification failure, not a demonstrated production path where the real aggregate accepts missing required work. The full-suite log subsequently terminated with 3,176 total, 3,174 succeeded, one failed and one Windows-only skip; its one failure was this older test row.

**Additional source inspected before delivery:** `DotNetGroupExecutionTests.cs` now names the scenario `CliRetainsExecutionOwnerOutcomeAndMissingRequiredResults`, supplies `ResultCollector.Collect(plan, results)` as the mocked owner's outcome, and asserts the transferred satisfaction, comparison, scope and missing-check count. This is consistent with the reviewed aggregate ownership boundary; the actual group owner's existing missing-result coverage remains. This changed test was absent from the original 20-file preview and was included as the twenty-first reviewed file. The old full-suite failure does not qualify this revision. This paragraph reports a later source delta, not GOV-011 classification of F1 or a passing execution claim.

Independent GOV-011 classification is now recorded in `/tmp/v3-caller-F1-triage.md`. Its inspected test SHA-256, `211c9f385ce1fcc1465fa5631e37f63e7ef029593884436f95c11f66ec46a2a7`, matches the current file and saved twenty-one-file fingerprints. No repeated source repair or restoration of CLI recollection is needed.

## Reviewed boundaries

I read the accepted repository instructions, governance/record policy and Wave, project handoff and relevant requirements/HLD/MLD/integration sections, shared engineering guidance, OCR delegation/rules, research-evidence review, and test-anti-patterns guidance with .NET/Python extensions. No root/current-directory `AGENTS.local.md` was present. The original audit and preimplementation classification were context, not substitutes for inspecting the proposed source.

- **Four ecosystems:** the finite typed `job-inputs` boundary owns concrete requests, exact subjects and producer/run/attempt validation, original copying, phase inputs and typed absent-state output. New npm/NuGet support retains distinct typed preparations and destinations. Internal transfer format changes migrate their actual callers together; no universal adapter or compatibility service is introduced. Duplicate-property rejection now uses the existing Release reader.
- **Native/platform boundaries:** Bash/PowerShell command execution, explicit Windows NuGet runners, runtime bootstrap, immutable artifact-ID downloads and digest enforcement, native Environment gates, permissions and workflow concurrency remain with their existing owners. NuGet's retained source-selection guard establishes equality of selected inputs with the Actions source/ref before the shared request reads `GITHUB_SHA/GITHUB_REF`. Runtime installation precedes migrated validation on receivers.
- **npm initial publication information:** completion validates the bound complete initial observation and distinguishes initially exact/no-publication from initially absent/missing-publication. The latter remains Unknown, even with exact final bytes. Final consumers remain required; publication subject and upload outcomes remain validated. The caller transfers the initial observation by immutable ID and validates its producer. Official simulation produces its consumed request without unused producer transfer records and remains read-only/hypothetical.
- **Same-owner CI outcomes:** .NET/Python/Ruby receivers bind comparison/candidate/scope and reject missing/malformed outcomes, retain raw results and diagnostics, and forward failure rather than spawn the same business collector again. Real group owners still evaluate the original complete plan. Node's independent runtime join and Ruby's single empty-result collection remain distinct.
- **Tests:** extended typed caller tests cover concrete subjects, producer substitution, original paths/bytes, phase inputs, missing/linked transfers and write-state enum serialization. The new NuGet test reads actual YAML `run` scripts, executes PowerShell and the actual typed state/phase/completion CLI, and substitutes destination reads/consumer results. Its assertions protect both casing-sensitive write-state output and successful/failed consumer completion; it makes no service or Actions scheduling claim. npm tests cover exact versus initially absent, omitted publication and failed consumers. The .NET test-contract mismatch recorded as F1 has been independently classified and repaired.

The finite Python runner-preparation candidate is unchanged and remains unresolved for owner disposition under the supplied classification. Identifying its actual runner infrastructure in the record does not establish global architectural closure. Costs/P95 remain with Agent01a13452; this review establishes no latency improvement.

## Original qualification evidence and limits

- `/tmp/v3-caller-focused-repaired.log`: terminal managed result, 209 succeeded, zero failed/skipped.
- `/tmp/v3-caller-python-focused.log`: terminal result, 236 passed.
- `/tmp/v3-caller-wire-repaired.log`: terminal result, four passed.
- `/tmp/v3-caller-managed-full.log`: terminal failure on the older test source, 3,176 total, 3,174 succeeded, one failed (F1), one Windows-only skip. It is not passed and does not qualify the later test edit.
- `/tmp/v3-caller-python-full.log`: collection failed with 13 missing-module errors. `/tmp/v3-caller-eng-full.log` failed collection because `markdown_it` was unavailable. `/tmp/v3-caller-record-check.log` has the same dependency failure; it is not a record-check pass.
- `/tmp/v3-caller-hk.log` records line-length failure; `/tmp/v3-caller-hk-repaired.log` still records Markdown formatting/lint failures. Neither establishes complete HK success. These are qualification limits, not additional material architectural findings.

Later logs were also inspected: `/tmp/v3-caller-hk-final.log` contains completed successful changed-file checks for its earlier subject; `/tmp/v3-caller-eng-full-prepared.log` contains progress without a terminal summary at inspection. `/tmp/v3-caller-record-check-repaired.log` contains only package-install output and no explicit checker result. Neither incomplete log is reported as a passing gate. The final integration-record delta removes the runner-preparation declaration from the newly added aggregate paragraph; it does not disposition the unresolved candidate.

`/tmp/v3-caller-managed-full-repaired.log` was inspected after the test delta; no terminal passing summary was available. Its existence does not establish successful requalification.

Earlier failed focused/wire runs remain distinct from later successful focused runs. The pending statuses in this historical section were accurate at the first inspection; the final recheck below records subsequent terminal results. Supplied local successes do not establish Windows native qualification, current deployed authentication/destination behavior or publication readiness.

## Final evidence recheck

All twenty-one saved fingerprints in `/tmp/v3-caller-source-review-sha256.txt` matched current source on the final recheck. The repaired .NET CLI test was reread and matches independent F1 triage. No source delta required another implementation review.

- **Managed complete suite:** `/tmp/v3-caller-managed-full-repaired.log` was inspected in full, including attachments and terminal summary: 3,176 total, 3,175 succeeded, zero failed, one skip (`BindAcceptsRootCaseDifference`, supported only on Windows). Terminal result is Passed. This establishes local requalification and supplies F1's previously pending execution evidence.
- **Engineering complete suite:** `/tmp/v3-caller-eng-full-prepared.log` contains the terminal result `543 passed in 296.39s`. The earlier dependency/collection failure is retained separately.
- **HK final subject:** `/tmp/v3-caller-hk-final-snapshot.log` was inspected in full. It selects twenty-one changed files, records successful actionlint, Markdown lint/format, Ruff lint/format, typos and editorconfig checks, and contains no nonzero child exit, abort or error. This is observed changed-file check evidence. I did not query or resume PTY 85101; root will independently verify its terminal status. I do not turn the log into an unobserved process-exit receipt.
- **Independent record review:** `/tmp/v3-caller-record-review-report.md` reports `No material findings.`
- **Record checker:** `/tmp/v3-caller-record-check.json` was parsed in full. Its sole diagnostic is `classification-unresolved` for unchanged `tests/private/app/workflow-delivery/testconfig.json`; its current hash is `a109dc93542f68f41e481a3ca8e7a3439d401735af1dc56d1b850fab1ac8d84e`, matching the recorded entry, and its diff against the accepted base is empty. Retain the reported exit 1 and diagnostic; this is not a mechanical record-check pass. The JSON captures an earlier .NET test blob, so it is not used as the final twenty-one-file identity manifest. Final source identity is supplied by the separately verified fingerprints. Its declared unavailable contextual/domain checks remain unavailable.

Local `origin/main` is `3c34d69eb0a720369e32fe62a77e9b50ab0da891`. Read-only comparison against base `7be1babcb429c97bc68e3aa7a00f4faa4cccb3bf` shows changes only to `Directory.Packages.props` and the OxfordLearnersDictionaryProcessor package lock, from the RocksDB dependency update. The reviewed architecture source, accepted Wave and governing review instructions are unchanged between these refs. This is verification of the available local ref, not a network refresh or rebase.

The original failures remain authoritative for their earlier subjects. No performance/P95, live publication, deployed permission/destination, or Windows-native qualification claim follows from these local results. The unchanged finite Python preparation candidate still awaits owner disposition; the cost worker retains performance ownership. Final engineering/OCR result for the bounded source: **No material findings.**

## Source coverage and execution limits

All original 20 manifest paths were reviewed, including the new `NuGetWorkflowCallerTests.cs` and all six OCR exclusions: the application README, handoff, migration strategy, and three `tests/eng` files. The manifest was expanded during review to include the changed `DotNetGroupExecutionTests.cs`; its full delta was reviewed as the twenty-first file. Applicable neighboring source/tests were inspected to resolve ownership and failure behavior. Final file fingerprints are in `/tmp/v3-caller-source-review-sha256.txt`; all twenty-one matched at the final comparison.

No tracked source was edited. No builds, tests, experiments, dispatches, publication, credential acquisition or external writes were performed. Only this report and its source-fingerprint attachment were written under `/tmp`. Findings do not authorize any such effects. Later source edits require review of their delta.
