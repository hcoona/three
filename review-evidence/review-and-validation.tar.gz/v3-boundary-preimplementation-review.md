The bounded contraction directions are supportable. **Seven findings are true positives; the “redundant control-test resource query” finding remains unresolved as a removal claim.** The neutral schema approach is sound, but its wire-contract mapping and exporter behavior still require qualification.

Reviewed independently against clean checkout `f33d59ffc7533ceee17fcd0ff17d6c49ec3b73a4`, matching the local `origin/main` ref. This review covers the eight enumerated findings and the proposal’s final neutral-contract approach. It does not establish performance, native execution or publication readiness. No files were edited, tests run, native experiments executed or GitHub writes performed.

**GOV-011 classifications**

Paths below are repository-relative. Application source references are under `src/private/app/workflow-delivery/`.

1. **Control task/binlog interpretation and fresh basis compilation — true positive, confidence 9/10; advisory architecture finding.**

   **Evidence:** `Repository/ControlBuildInputProjection.cs:17–76` maintains compiler parameters and a substantial task allowlist; lines 168–187 enforce supported task names and implementation associations. `Repository/ControlBuildLogReader.cs:183–195` requires an actual compiler invocation. `Repository/NodeGroupReader.cs:117–137` consumes that projection for both endpoints. `eng/scripts/run_dotnet_ci_group.py:104–117` builds a distinct present basis, and `eng/scripts/run_node_ci_group.py:347–353` does likewise. `Repository/DotNetGroupReader.cs:113–117` then associates control source inputs with all native .NET consumers.

   **Classification boundary:** This is a finite, currently documented adapter—not evidence of a shadow authorization system or an incorrect native resolver. Its precision and fresh-build prerequisite are nevertheless credible contraction targets when genuine control changes already have broad consumers.

   **Smallest action:** Establish the bounded source/configuration/native-import/helper input contract at both revisions, then remove basis compilation and projection machinery whose consumers have disappeared. Preserve usable candidate control, native preparation, deletion/rename facts and explicit unsupported outcomes. Candidate binlogs may remain diagnostics.

2. **Node product installation at planning endpoints — true positive, confidence 9/10; advisory preparation finding.**

   **Evidence:** `eng/scripts/run_node_ci_group.py:302–335` performs frozen product installation at both endpoints before selection. `Repository/PnpmGraphReader.cs:170–172` obtains dependency facts with `--lockfile-only`; its metadata queries use native `pkg get`. Selected execution separately prepares product dependencies.

   **Classification boundary:** Source supports unnecessary coupling between planning and installation. It does not establish that removing installation already works in every supported caller context or quantify savings.

   **Smallest action:** Remove endpoint product installs after qualifying the retained native queries and configuration dependencies. Keep locked tool preparation, metadata/version facts, failure propagation and selected execution’s product installation.

3. **Redundant control-test resource query — unresolved, confidence 9/10; blocking for unconditional deletion.**

   **Evidence:** `eng/scripts/run_dotnet_ci_group.py:90–99` restores `dirs.proj`, which includes the control test project. `eng/scripts/prepare_ci_control_inputs.py:147–167` separately restores that project and invokes its resource query. `Repository/DotNetGraph.cs:27–31` already collects `EmbeddedResource`.

   However, the contexts are not identical by construction: `Repository/MsBuildResourceReader.cs:51–63` queries the default Debug context without TFM/RID overrides; `Repository/DotNetRepositoryReader.cs:60–66` constructs the graph with additional CI and locked-restore globals. Current resource querying also precedes final graph-based selection.

   **Smallest action:** Establish one sufficient evaluation context and restructure the consumer ordering before deleting the query. Preserve conditional resources, resource-only changes, deleted/renamed inputs, basis-owner absence and failed evaluation. If equivalence cannot be established, retain the necessary query; any change to the accepted resource-context behavior requires owner disposition in the governing carrier.

4. **Duplicate tool pins and runtime matrix — true positive, confidence 10/10; advisory authority finding.**

   **Evidence:** `Destinations/GithubNpmPublication.cs:37–43` and `Destinations/GithubNpmConsumer.cs:47–50` independently encode the same Node/npm versions selected by the concrete workflow. `Repository/NodeRuntimeInputs.cs:15–17`, 31–32 and 98–111 hardcodes the two matrix selectors and packaging choice despite reading the workflow matrix. `CI/NodeExecution.cs:201` also binds execution to those selector literals.

   **Smallest action:** Derive selection from the existing maintained configuration and pass expected identities through concrete operation inputs, retaining actual version checks. Reconcile planner, executor and collector together. Preserve the presently accepted Node 24 packaging obligation until its replacement contract is accepted.

   Finite adapter limits, historical evidence versions and fixture versions are **not** automatically duplicate live pins.

5. **File role versus actual consumption, including documentation — true positive, confidence 9/10; advisory selection finding.**

   **Evidence:** `Repository/DotNetOwnership.cs:35–43` maps nearest-project regions subject to native excludes. `Repository/DotNetGraph.cs:27–31` includes `None` and `Content`; `Repository/DotNetFactsAssembler.cs:163–167` maps bound inputs to consumers without operation-role differentiation. `Repository/PythonRepositoryInputs.cs:28–35` and 199–209 independently retain whole-directory control/test bindings.

   Counterexamples prevent universal documentation exclusion: `src/public/lib/hexo-renderer-asciidoc/package.json:8–19` packages documentation and transforms README during packing; the Asciidoctor gemspec includes README, and its version configuration includes the project.

   **Smallest action:** Narrow only demonstrably inert control documentation through native exclusions and reconcile downstream bindings that would otherwise reselect it. Preserve actual resource, copy, package, test and version inputs, record checks, paired closure and complete selected checks. Assess concrete supported operations separately across all four ecosystems; do not introduce an extension filter or task-I/O inference engine.

6. **Ruby/Python nonnative release glue — true positive, confidence 10/10; advisory responsibility finding.**

   **Evidence:** Both `Native/Ruby/release_caller.rb` and `Native/Python/release_caller.py` create requests, bind subjects/producers, transfer originals and prepare phase/tool inputs. These responsibilities are application orchestration. The corresponding workflows already build and distribute the C# control before invoking this glue; Python’s ordering is explicit at `.github/workflows/workflow-delivery-v3-python-smoke.yml:53–60`.

   **Smallest action:** Consolidate this glue into the existing application under accepted decision A, atomically updating callers and removing obsolete contracts. Retain native-library helpers, Actions job/permission orchestration, immutable transfer identity, subject checks and original-byte validation. Consolidation does not justify a general workflow engine.

7. **Fixture recipes inside broadly named ecosystem operations — true positive, confidence 10/10; advisory abstraction finding.**

   **Evidence:** `Ecosystems/RubyPackageOperations.cs:20–22`, 44–51 and 103–119 embeds the fixture coordinate, exact contents, dependency-free restriction and API assertion. `Native/Ruby/consumer.rb:16` and 38–53 similarly contains fixture-specific consumption behavior.

   **Classification boundary:** This demonstrates responsibility coupling, not failure to deliver promised general gem support. Current implemented scope is explicitly finite.

   **Smallest action:** Give concrete product recipes explicit ownership and names while retaining native archive/install mechanisms and required byte/origin checks. Obtain identities from existing declarations/native facts where supported. Do not add a plugin framework, automatic onboarding or dependency/native-extension support.

8. **Optional unused witness compatibility — true positive, confidence 10/10; advisory retirement finding.**

   **Evidence:** The Ruby fixture gemspec’s lines 23–24 optionally package `_workflow_delivery_provenance.json`; `Ecosystems/RubyPackageOperations.cs:46–47` filters it before CI contents comparison. Release inspection at lines 67–75 requires the exact contents and therefore rejects the additional file. Tests exercise the accommodation, while `Repository/RubySourceCollectorTests.cs:86–87` verifies that current source preparation does not create it.

   **Smallest action:** Remove optional packaging and acceptance accommodation, coordinating affected test changes. Preserve relevant native provenance, exact archive rejection behavior and historical evidence consumers.

   The claim that current authorization depends on this witness would be **false positive**; the narrowly stated compatibility-residue finding is valid.

**Neutral schema approach**

Approve the architectural direction conditionally: ordinary JSON, one maintained application-owned wire contract, generated static schemas only for surviving independent consumers, and native-language tests that can consume those schemas without building the control application.

No generated schema artifact was supplied with the task, and I found no schema exporter implementation or generated schema artifacts in the reviewed application/test tree. This is therefore an approach review, **not approval of generated output**.

Two concrete prerequisites remain:

- **Describe the wire shape, not an internal projection.** `Repository/RubyNativeFactsReader.cs:27–40` constructs nested C# values from flattened helper JSON; lines 82–87 consume snake-case fields. Exporting `RubySourceGemFacts` or `RubyArchiveFacts` directly would describe a different message. Conversely, `RubyFactRequest` is an actual serialized request, and `PythonSupplementRequest` has its own snake-case serializer context. Establish the retained producer/consumer messages after glue consolidation and generate from their actual wire contracts.
- **Qualify the exact serializer/exporter combination.** `Program.cs:292–301` sets camel-case names, nullable/constructor-required behavior and rejection of unknown members; lines 378–397 register enum-converter subclasses. Generated output must preserve the intended literals, requiredness, nullability, arrays, nested structures and unknown-field behavior. Unconstrained schema output cannot establish agreement.

These are blocking acceptance conditions for the schema implementation, not reasons to reject the neutral approach. Export neither every `TransferJson` registration nor upstream PNPM/MSBuild formats. Application-created native-fact projections qualify; upstream formats remain upstream-owned. Shape tests must remain separate from semantic checks for native evaluation, revision/path meaning, process termination, transfer binding and business outcomes.

**Existing fixes and check ownership**

Git records PR #1160 as merged in this snapshot. Its changes address .NET execution scheduling and native fixture/test preparation; they do not remove the planning and boundary mechanisms above. Those findings remain applicable. I did not verify hosted checks or performance results.

Coordinate concrete scheduling, fixture matrices and test rewrites with session `01a13452-7494-7631-8bde-2702620b212d`. C# owns consolidated application behavior and serialization; native helpers own their bindings; small integration cases establish real interoperability. HK retains source/configuration conformance, and CI retains complete selected checks, variants and truthful missing/failed/cancelled/unknown outcomes.

This review supports preparing coherent requirements/HLD/MLD/caller changes within the accepted contraction scope. Finding 3 remains open, and schema output remains unqualified. Neither permits coverage expansion, publication, campaign replay or a latency claim.

